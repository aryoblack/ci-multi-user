#
# TABLE STRUCTURE FOR: aplikasi
#

DROP TABLE IF EXISTS `aplikasi`;

CREATE TABLE `aplikasi` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nama_owner` varchar(100) DEFAULT NULL,
  `alamat` text DEFAULT NULL,
  `tlp` varchar(50) DEFAULT NULL,
  `title` varchar(20) DEFAULT NULL,
  `nama_aplikasi` varchar(100) DEFAULT NULL,
  `logo` varchar(100) DEFAULT NULL,
  `copy_right` varchar(50) DEFAULT NULL,
  `versi` varchar(20) DEFAULT NULL,
  `tahun` year(4) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4;

INSERT INTO `aplikasi` (`id`, `nama_owner`, `alamat`, `tlp`, `title`, `nama_aplikasi`, `logo`, `copy_right`, `versi`, `tahun`) VALUES (1, 'PT. PPSU', 'JL. Rawabali', '0812-9936-9059', 'SITPDT', 'Sistem Informasi Tiket Penyebrangan Danau Toba', 'AdminLTELogo1.png', 'Copy Right &copy;', '1.0.0.0', '2020');


#
# TABLE STRUCTURE FOR: barang
#

DROP TABLE IF EXISTS `barang`;

CREATE TABLE `barang` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `kdbarang` varchar(15) DEFAULT NULL,
  `nama` varchar(50) DEFAULT NULL,
  `harga` decimal(10,0) DEFAULT NULL,
  `satuan` varchar(15) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4;

#
# TABLE STRUCTURE FOR: kategori
#

DROP TABLE IF EXISTS `kategori`;

CREATE TABLE `kategori` (
  `id_kat` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `nama_kat` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id_kat`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4;

#
# TABLE STRUCTURE FOR: tbl_akses_menu
#

DROP TABLE IF EXISTS `tbl_akses_menu`;

CREATE TABLE `tbl_akses_menu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_level` int(11) NOT NULL,
  `id_menu` int(11) NOT NULL,
  `view_level` enum('Y','N') DEFAULT 'N',
  `add_level` enum('Y','N') DEFAULT 'N',
  `edit_level` enum('Y','N') DEFAULT 'N',
  `delete_level` enum('Y','N') DEFAULT 'N',
  `print_level` enum('Y','N') DEFAULT 'N',
  `upload_level` enum('Y','N') DEFAULT 'N',
  `v_btn` enum('Y','N') DEFAULT 'N',
  `v_btn1` enum('Y','N') DEFAULT 'N',
  `v_btn2` enum('Y','N') DEFAULT 'N',
  PRIMARY KEY (`id`),
  KEY `id_menu` (`id_menu`),
  KEY `id_level` (`id_level`)
) ENGINE=InnoDB AUTO_INCREMENT=76 DEFAULT CHARSET=utf8mb4;

INSERT INTO `tbl_akses_menu` (`id`, `id_level`, `id_menu`, `view_level`, `add_level`, `edit_level`, `delete_level`, `print_level`, `upload_level`, `v_btn`, `v_btn1`, `v_btn2`) VALUES (1, 1, 1, 'Y', 'N', 'N', 'N', 'N', 'N', 'Y', 'Y', 'N');
INSERT INTO `tbl_akses_menu` (`id`, `id_level`, `id_menu`, `view_level`, `add_level`, `edit_level`, `delete_level`, `print_level`, `upload_level`, `v_btn`, `v_btn1`, `v_btn2`) VALUES (2, 1, 2, 'Y', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N');
INSERT INTO `tbl_akses_menu` (`id`, `id_level`, `id_menu`, `view_level`, `add_level`, `edit_level`, `delete_level`, `print_level`, `upload_level`, `v_btn`, `v_btn1`, `v_btn2`) VALUES (43, 4, 1, 'Y', 'Y', 'N', 'N', 'N', 'N', 'N', 'N', 'N');
INSERT INTO `tbl_akses_menu` (`id`, `id_level`, `id_menu`, `view_level`, `add_level`, `edit_level`, `delete_level`, `print_level`, `upload_level`, `v_btn`, `v_btn1`, `v_btn2`) VALUES (44, 4, 2, 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N');
INSERT INTO `tbl_akses_menu` (`id`, `id_level`, `id_menu`, `view_level`, `add_level`, `edit_level`, `delete_level`, `print_level`, `upload_level`, `v_btn`, `v_btn1`, `v_btn2`) VALUES (64, 5, 1, 'Y', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N');
INSERT INTO `tbl_akses_menu` (`id`, `id_level`, `id_menu`, `view_level`, `add_level`, `edit_level`, `delete_level`, `print_level`, `upload_level`, `v_btn`, `v_btn1`, `v_btn2`) VALUES (65, 5, 2, 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N');
INSERT INTO `tbl_akses_menu` (`id`, `id_level`, `id_menu`, `view_level`, `add_level`, `edit_level`, `delete_level`, `print_level`, `upload_level`, `v_btn`, `v_btn1`, `v_btn2`) VALUES (73, 1, 55, 'Y', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N');
INSERT INTO `tbl_akses_menu` (`id`, `id_level`, `id_menu`, `view_level`, `add_level`, `edit_level`, `delete_level`, `print_level`, `upload_level`, `v_btn`, `v_btn1`, `v_btn2`) VALUES (74, 4, 55, 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N');
INSERT INTO `tbl_akses_menu` (`id`, `id_level`, `id_menu`, `view_level`, `add_level`, `edit_level`, `delete_level`, `print_level`, `upload_level`, `v_btn`, `v_btn1`, `v_btn2`) VALUES (75, 5, 55, 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N');


#
# TABLE STRUCTURE FOR: tbl_akses_submenu
#

DROP TABLE IF EXISTS `tbl_akses_submenu`;

CREATE TABLE `tbl_akses_submenu` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `id_level` int(11) NOT NULL,
  `id_submenu` int(11) NOT NULL,
  `view_level` enum('Y','N') DEFAULT 'N',
  `add_level` enum('Y','N') DEFAULT 'N',
  `edit_level` enum('Y','N') DEFAULT 'N',
  `delete_level` enum('Y','N') DEFAULT 'N',
  `print_level` enum('Y','N') DEFAULT 'N',
  `upload_level` enum('Y','N') DEFAULT 'N',
  `v_btn` enum('Y','N') DEFAULT 'N',
  PRIMARY KEY (`id`),
  KEY `id_submenu` (`id_submenu`),
  KEY `id_level` (`id_level`)
) ENGINE=InnoDB AUTO_INCREMENT=150 DEFAULT CHARSET=utf8mb4;

INSERT INTO `tbl_akses_submenu` (`id`, `id_level`, `id_submenu`, `view_level`, `add_level`, `edit_level`, `delete_level`, `print_level`, `upload_level`, `v_btn`) VALUES (2, 1, 2, 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', 'N');
INSERT INTO `tbl_akses_submenu` (`id`, `id_level`, `id_submenu`, `view_level`, `add_level`, `edit_level`, `delete_level`, `print_level`, `upload_level`, `v_btn`) VALUES (4, 1, 1, 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', 'N');
INSERT INTO `tbl_akses_submenu` (`id`, `id_level`, `id_submenu`, `view_level`, `add_level`, `edit_level`, `delete_level`, `print_level`, `upload_level`, `v_btn`) VALUES (6, 1, 7, 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', 'N');
INSERT INTO `tbl_akses_submenu` (`id`, `id_level`, `id_submenu`, `view_level`, `add_level`, `edit_level`, `delete_level`, `print_level`, `upload_level`, `v_btn`) VALUES (7, 1, 8, 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', 'N');
INSERT INTO `tbl_akses_submenu` (`id`, `id_level`, `id_submenu`, `view_level`, `add_level`, `edit_level`, `delete_level`, `print_level`, `upload_level`, `v_btn`) VALUES (9, 1, 10, 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', 'N');
INSERT INTO `tbl_akses_submenu` (`id`, `id_level`, `id_submenu`, `view_level`, `add_level`, `edit_level`, `delete_level`, `print_level`, `upload_level`, `v_btn`) VALUES (59, 4, 1, 'N', 'N', 'N', 'N', 'N', 'N', 'N');
INSERT INTO `tbl_akses_submenu` (`id`, `id_level`, `id_submenu`, `view_level`, `add_level`, `edit_level`, `delete_level`, `print_level`, `upload_level`, `v_btn`) VALUES (60, 4, 2, 'N', 'N', 'N', 'N', 'N', 'N', 'N');
INSERT INTO `tbl_akses_submenu` (`id`, `id_level`, `id_submenu`, `view_level`, `add_level`, `edit_level`, `delete_level`, `print_level`, `upload_level`, `v_btn`) VALUES (61, 4, 7, 'N', 'N', 'N', 'N', 'N', 'N', 'N');
INSERT INTO `tbl_akses_submenu` (`id`, `id_level`, `id_submenu`, `view_level`, `add_level`, `edit_level`, `delete_level`, `print_level`, `upload_level`, `v_btn`) VALUES (62, 4, 8, 'N', 'N', 'N', 'N', 'N', 'N', 'N');
INSERT INTO `tbl_akses_submenu` (`id`, `id_level`, `id_submenu`, `view_level`, `add_level`, `edit_level`, `delete_level`, `print_level`, `upload_level`, `v_btn`) VALUES (63, 4, 10, 'N', 'N', 'N', 'N', 'N', 'N', 'N');
INSERT INTO `tbl_akses_submenu` (`id`, `id_level`, `id_submenu`, `view_level`, `add_level`, `edit_level`, `delete_level`, `print_level`, `upload_level`, `v_btn`) VALUES (106, 5, 1, 'N', 'N', 'N', 'N', 'N', 'N', 'N');
INSERT INTO `tbl_akses_submenu` (`id`, `id_level`, `id_submenu`, `view_level`, `add_level`, `edit_level`, `delete_level`, `print_level`, `upload_level`, `v_btn`) VALUES (107, 5, 2, 'N', 'N', 'N', 'N', 'N', 'N', 'N');
INSERT INTO `tbl_akses_submenu` (`id`, `id_level`, `id_submenu`, `view_level`, `add_level`, `edit_level`, `delete_level`, `print_level`, `upload_level`, `v_btn`) VALUES (108, 5, 7, 'N', 'N', 'N', 'N', 'N', 'N', 'N');
INSERT INTO `tbl_akses_submenu` (`id`, `id_level`, `id_submenu`, `view_level`, `add_level`, `edit_level`, `delete_level`, `print_level`, `upload_level`, `v_btn`) VALUES (109, 5, 8, 'N', 'N', 'N', 'N', 'N', 'N', 'N');
INSERT INTO `tbl_akses_submenu` (`id`, `id_level`, `id_submenu`, `view_level`, `add_level`, `edit_level`, `delete_level`, `print_level`, `upload_level`, `v_btn`) VALUES (110, 5, 10, 'N', 'N', 'N', 'N', 'N', 'N', 'N');
INSERT INTO `tbl_akses_submenu` (`id`, `id_level`, `id_submenu`, `view_level`, `add_level`, `edit_level`, `delete_level`, `print_level`, `upload_level`, `v_btn`) VALUES (141, 1, 47, 'Y', 'N', 'N', 'N', 'N', 'N', 'N');
INSERT INTO `tbl_akses_submenu` (`id`, `id_level`, `id_submenu`, `view_level`, `add_level`, `edit_level`, `delete_level`, `print_level`, `upload_level`, `v_btn`) VALUES (142, 4, 47, 'N', 'N', 'N', 'N', 'N', 'N', 'N');
INSERT INTO `tbl_akses_submenu` (`id`, `id_level`, `id_submenu`, `view_level`, `add_level`, `edit_level`, `delete_level`, `print_level`, `upload_level`, `v_btn`) VALUES (143, 5, 47, 'N', 'N', 'N', 'N', 'N', 'N', 'N');
INSERT INTO `tbl_akses_submenu` (`id`, `id_level`, `id_submenu`, `view_level`, `add_level`, `edit_level`, `delete_level`, `print_level`, `upload_level`, `v_btn`) VALUES (144, 1, 48, 'N', 'N', 'N', 'N', 'N', 'N', 'N');
INSERT INTO `tbl_akses_submenu` (`id`, `id_level`, `id_submenu`, `view_level`, `add_level`, `edit_level`, `delete_level`, `print_level`, `upload_level`, `v_btn`) VALUES (145, 4, 48, 'N', 'N', 'N', 'N', 'N', 'N', 'N');
INSERT INTO `tbl_akses_submenu` (`id`, `id_level`, `id_submenu`, `view_level`, `add_level`, `edit_level`, `delete_level`, `print_level`, `upload_level`, `v_btn`) VALUES (146, 5, 48, 'N', 'N', 'N', 'N', 'N', 'N', 'N');
INSERT INTO `tbl_akses_submenu` (`id`, `id_level`, `id_submenu`, `view_level`, `add_level`, `edit_level`, `delete_level`, `print_level`, `upload_level`, `v_btn`) VALUES (147, 1, 49, 'N', 'N', 'N', 'N', 'N', 'N', 'N');
INSERT INTO `tbl_akses_submenu` (`id`, `id_level`, `id_submenu`, `view_level`, `add_level`, `edit_level`, `delete_level`, `print_level`, `upload_level`, `v_btn`) VALUES (148, 4, 49, 'N', 'N', 'N', 'N', 'N', 'N', 'N');
INSERT INTO `tbl_akses_submenu` (`id`, `id_level`, `id_submenu`, `view_level`, `add_level`, `edit_level`, `delete_level`, `print_level`, `upload_level`, `v_btn`) VALUES (149, 5, 49, 'N', 'N', 'N', 'N', 'N', 'N', 'N');


#
# TABLE STRUCTURE FOR: tbl_menu
#

DROP TABLE IF EXISTS `tbl_menu`;

CREATE TABLE `tbl_menu` (
  `id_menu` int(11) NOT NULL AUTO_INCREMENT,
  `nama_menu` varchar(50) DEFAULT NULL,
  `link` varchar(100) DEFAULT NULL,
  `icon` varchar(50) DEFAULT NULL,
  `urutan` bigint(11) DEFAULT NULL,
  `is_active` enum('Y','N') DEFAULT 'Y',
  `parent` enum('Y') DEFAULT 'Y',
  PRIMARY KEY (`id_menu`)
) ENGINE=InnoDB AUTO_INCREMENT=56 DEFAULT CHARSET=utf8mb4;

INSERT INTO `tbl_menu` (`id_menu`, `nama_menu`, `link`, `icon`, `urutan`, `is_active`, `parent`) VALUES (1, 'Dashboard', 'dashboard', 'fas fa-tachometer-alt', '1', 'Y', 'Y');
INSERT INTO `tbl_menu` (`id_menu`, `nama_menu`, `link`, `icon`, `urutan`, `is_active`, `parent`) VALUES (2, 'System', '#', 'fas fa-cogs', '10', 'Y', 'Y');
INSERT INTO `tbl_menu` (`id_menu`, `nama_menu`, `link`, `icon`, `urutan`, `is_active`, `parent`) VALUES (55, 'Master', '#', 'fa fa-database', '3', 'Y', 'Y');


#
# TABLE STRUCTURE FOR: tbl_submenu
#

DROP TABLE IF EXISTS `tbl_submenu`;

CREATE TABLE `tbl_submenu` (
  `id_submenu` int(11) NOT NULL AUTO_INCREMENT,
  `nama_submenu` varchar(50) DEFAULT NULL,
  `link` varchar(100) DEFAULT NULL,
  `icon` varchar(50) DEFAULT NULL,
  `id_menu` int(11) DEFAULT NULL,
  `is_active` enum('Y','N') DEFAULT 'Y',
  PRIMARY KEY (`id_submenu`),
  KEY `id_menu` (`id_menu`),
  CONSTRAINT `tbl_submenu_ibfk_1` FOREIGN KEY (`id_menu`) REFERENCES `tbl_menu` (`id_menu`)
) ENGINE=InnoDB AUTO_INCREMENT=50 DEFAULT CHARSET=utf8mb4;

INSERT INTO `tbl_submenu` (`id_submenu`, `nama_submenu`, `link`, `icon`, `id_menu`, `is_active`) VALUES (1, 'Menu', 'menu', 'far fa-circle', 2, 'Y');
INSERT INTO `tbl_submenu` (`id_submenu`, `nama_submenu`, `link`, `icon`, `id_menu`, `is_active`) VALUES (2, 'SubMenu', 'submenu', 'far fa-circle', 2, 'Y');
INSERT INTO `tbl_submenu` (`id_submenu`, `nama_submenu`, `link`, `icon`, `id_menu`, `is_active`) VALUES (7, 'Aplikasi', 'aplikasi', 'far fa-circle', 2, 'Y');
INSERT INTO `tbl_submenu` (`id_submenu`, `nama_submenu`, `link`, `icon`, `id_menu`, `is_active`) VALUES (8, 'User', 'user', 'far fa-circle', 2, 'Y');
INSERT INTO `tbl_submenu` (`id_submenu`, `nama_submenu`, `link`, `icon`, `id_menu`, `is_active`) VALUES (10, 'User Level', 'userlevel', 'far fa-circle', 2, 'Y');
INSERT INTO `tbl_submenu` (`id_submenu`, `nama_submenu`, `link`, `icon`, `id_menu`, `is_active`) VALUES (47, 'Barang', 'barang', 'far fa-circle', 55, 'Y');
INSERT INTO `tbl_submenu` (`id_submenu`, `nama_submenu`, `link`, `icon`, `id_menu`, `is_active`) VALUES (48, 'Tester 1', '#', 'far fa-circle', 55, 'Y');
INSERT INTO `tbl_submenu` (`id_submenu`, `nama_submenu`, `link`, `icon`, `id_menu`, `is_active`) VALUES (49, 'tester', '#', 'far fa-circle', 55, 'Y');


#
# TABLE STRUCTURE FOR: tbl_user
#

DROP TABLE IF EXISTS `tbl_user`;

CREATE TABLE `tbl_user` (
  `id_user` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(20) DEFAULT NULL,
  `full_name` varchar(50) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `id_level` int(11) DEFAULT NULL,
  `image` varchar(500) DEFAULT NULL,
  `is_active` enum('Y','N') DEFAULT 'Y',
  `id_loket` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_user`),
  KEY `id_level` (`id_level`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4;

INSERT INTO `tbl_user` (`id_user`, `username`, `full_name`, `password`, `id_level`, `image`, `is_active`, `id_loket`) VALUES (1, 'admin', 'Administrator', '$2y$05$3oQlxl8wMGd8VecO4nFXre3SjeHWqFN79oMy/.pdEj5Q89xopj4oi', 1, 'admin1.jpg', 'Y', NULL);


#
# TABLE STRUCTURE FOR: tbl_userlevel
#

DROP TABLE IF EXISTS `tbl_userlevel`;

CREATE TABLE `tbl_userlevel` (
  `id_level` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `nama_level` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id_level`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4;

INSERT INTO `tbl_userlevel` (`id_level`, `nama_level`) VALUES (1, 'admin');
INSERT INTO `tbl_userlevel` (`id_level`, `nama_level`) VALUES (4, 'kasir');
INSERT INTO `tbl_userlevel` (`id_level`, `nama_level`) VALUES (5, 'amanah');


